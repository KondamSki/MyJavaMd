public class ValueDemo2{
	public static void main(String[] args){
	//�����Ʊ�ͼ
		System.out.println("name"+"\t"+"liu");
		System.out.println("age"+"\t"+"27");
	}
}